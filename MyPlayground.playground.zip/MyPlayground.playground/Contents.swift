struct Town{
    let name: String
    var citizens: [String]
    var resources: [String : Int]
    
    
    init(name: String, citizens: [String], resources: [String : Int] ) {
        self.name = name
        self.citizens = citizens
        self.resources = resources
    }
    
    func fourtify(){
        print("Defence increased")
    }
}
        


var anotherTown = Town(name: "Nameless Island", citizens: ["Raza Khan"], resources: ["Coconuts" : 100])
anotherTown.citizens.append("Willson Khan")
print(anotherTown.citizens)


var ghostTown = Town(name: "McGhostFace", citizens: ["👻"], resources: ["Tunbleweed" : 1])

ghostTown.citizens.append("Sana Khan")
ghostTown.fourtify()
print(ghostTown.citizens)
